<template>
    <div>article</div>
</template>
