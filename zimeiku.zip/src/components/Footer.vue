<template>
    <footer>
        <div class="inner-wrap">
            <p><span>自媒库 —— 自媒体人的媒体库</span></p>
            <p style="margin-bottom:25px;">CopyRight @2018 www.zimeiku.com All Rights Reserved  自媒库交易平台 V0.0.1 湘ICP备16011583号-2 </p>
            <!-- <p>湖南陶梦有限公司  地址：湖南省长沙市岳麓区 新长海中心B1 6A07  电话：12345678</p> -->
        </div>
    </footer>
</template>

<style>
footer{text-align: center;width: 100%;min-width: 1200px;color: #a8a8a8;background: #373d41;font-size: 14px;float: left;padding-top: 25px;}
footer p{margin-top: 10px;}
</style>

